# Created By @GoToHellxD | @HwMods
LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := HwMods
LOCAL_SRC_FILES := prebuilt/$(TARGET_ARCH_ABI)/libHwMods.so
include $(PREBUILT_SHARED_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := Crash

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -fstack-protector-strong -fno-asynchronous-unwind-tables -fno-unwind-tables -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive
LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -fvisibility-inlines-hidden -ffunction-sections -fdata-sections -fstack-protector-strong -fno-asynchronous-unwind-tables -fno-unwind-tables -w -s -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all,-z,relro,-z,now,-z,noexecstack -llog
LOCAL_LDFLAGS += -Wl,--version-script,$(MAIN_LOCAL_PATH)/Crash.exports.map -Wl,--no-undefined-version
LOCAL_LDFLAGS += -Wl,--exclude-libs,ALL
LOCAL_ARM_MODE := arm

LOCAL_C_INCLUDES += $(MAIN_LOCAL_PATH)
LOCAL_SHARED_LIBRARIES := HwMods

LOCAL_SRC_FILES := Main.cpp \
	And64InlineHook/And64InlineHook.cpp \
	ImGui/imgui.cpp \
	ImGui/imgui_draw.cpp \
	ImGui/imgui_widgets.cpp \
	ImGui/imgui_tables.cpp \
	ImGui/backends/imgui_impl_opengl3.cpp \
	ImGui/backends/imgui_impl_android.cpp

LOCAL_LDLIBS := -llog -landroid -lGLESv2 -lGLESv3 -lEGL -ldl

include $(BUILD_SHARED_LIBRARY)
