package com.easyvictory.mods;

public interface HwMods1 {
    void onAnimationEnd(HwMods3 hTextView);
}
