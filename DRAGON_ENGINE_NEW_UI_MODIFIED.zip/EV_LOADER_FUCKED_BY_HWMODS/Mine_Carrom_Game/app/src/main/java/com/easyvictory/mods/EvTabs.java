package com.easyvictory.mods;

import java.util.Locale;

/**
 * Presentation-only grouping. The native library still publishes its own tabs
 * (Visuals, Play, Queue, Extras); the UI shows them under AIM and TOOLS, followed by
 * a SETTINGS page that is built in Java. Feature ids, labels and callbacks are untouched.
 */
final class EvTabs {
    static final int AIM = 0;
    static final int TOOLS = 1;
    static final int SETTINGS = 2;
    static final String[] TITLES = {"AIM", "TOOLS", "SETTINGS"};

    private EvTabs() {
    }

    /** Which UI tab a native tab is shown under. Unknown native tabs go to TOOLS. */
    static int groupFor(String nativeTitle) {
        String low = nativeTitle == null ? "" : nativeTitle.trim().toLowerCase(Locale.US);
        if (low.equals("play") || low.equals("visuals")) return AIM;
        return TOOLS;
    }

    /** Sort key of a native tab inside its UI tab (lower is shown first). */
    static int orderFor(String nativeTitle) {
        String low = nativeTitle == null ? "" : nativeTitle.trim().toLowerCase(Locale.US);
        if (low.equals("play") || low.equals("queue")) return 0;
        if (low.equals("visuals") || low.equals("extras")) return 1;
        return 5;
    }
}
